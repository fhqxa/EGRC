"""Standalone EGRC runtime components."""
